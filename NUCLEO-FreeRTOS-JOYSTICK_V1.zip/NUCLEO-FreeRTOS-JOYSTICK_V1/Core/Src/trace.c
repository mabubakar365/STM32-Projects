/*
 * trace.c
 *
 *  Created on:
 *      Author:
 */


/******************************************************************************/
/*----------------------------------Includes----------------------------------*/
/******************************************************************************/

#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "trace.h"

/******************************************************************************/
/*-------------------------Function Implementations---------------------------*/
/******************************************************************************/


void TRACE(char *str, ...) {
	int n;
	char str_new[150];
	va_list arg_list;
	va_start(arg_list, str);
	n = vsnprintf(str_new, sizeof(str_new), str, arg_list);
	va_end(arg_list);
	int i = 0;
	while(n!=0) {
		HAL_UART_Transmit(&huart2, (uint8_t *)&str_new[i], 1, 0xffff);
		n--;
		i++;
	}
}

void logs(char *str) {
	HAL_UART_Transmit(&huart2, (uint8_t *)&str, strlen(str), 0xffff);
}

void clrscr(void) {
	TRACE("\x1b[2J\x1b[1;1H");
}


