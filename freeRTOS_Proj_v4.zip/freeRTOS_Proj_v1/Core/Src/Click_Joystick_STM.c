/*
 * Click_Joystick_STM.c
 *
 *  Created on: Jun 24, 2023
 *      Author: sss
 */

#include "Click_Joystick_types.h"
#include "Click_Joystick_config.h"
#include "trace.h"
#include "joystick_click.h"
#include "main.h"

extern uint8_t direction;

uint8_t position;
uint8_t buttonState;
uint8_t positionOld = 1;
uint8_t buttonStateOld = 1;

void systemInit()
{
	/* Initialized interrupt, CS, reset pins as well as i2c module */
	HAL_GPIO_WritePin(GPIOB, RST_Pin, GPIO_PIN_SET);
}

void applicationInit()
{
//    joystick_i2cDriverInit( (T_JOYSTICK_P)&_MIKROBUS1_GPIO, (T_JOYSTICK_P)&_MIKROBUS1_I2C, _JOYSTICK_I2C_ADDRESS_0 );

    HAL_Delay(100);

    joystick_setDefaultConfiguration();

    TRACE( "---------------------\r\n");
    TRACE( "    Configuration    \r\n");
    TRACE( "---------------------\r\n");
    TRACE( "    Joystick Click   \r\n");
    TRACE( "---------------------\r\n");

    HAL_Delay(100);
}

void applicationTask()
{
    buttonState = joystick_pressButton();

    position = joystick_getPosition();

    HAL_Delay(10);

    if ( buttonState == 1 && buttonStateOld == 0 )
    {
        buttonStateOld = 1;

        TRACE("  Button is pressed \r\n");
        TRACE( "---------------------\r\n");
    }

    if ( buttonState == 0 && buttonStateOld == 1 )
    {
        buttonStateOld = 0;
    }

    if ( positionOld != position )
    {
        switch ( position )
        {
            case 0 :
            {
            	direction = 0x11;
                TRACE( "    Start position   \r\n");
                break;
            }
            case 1 :
            {
            	direction = 0x12;
                TRACE( "         Top        \r\n");
                break;
            }
            case 2 :
            {
            	direction = 0x13;
                TRACE( "      Top-Right     \r\n");
                break;
            }
            case 3 :
            {
            	direction = 0x14;
                TRACE( "        Right       \r\n");
                break;
            }
            case 4 :
            {
            	direction = 0x15;
                TRACE( "     Bottom-Right   \r\n");
                break;
            }
            case 5 :
            {
            	direction = 0x16;
                TRACE( "        Bottom      \r\n");
                break;
            }
            case 6 :
            {
            	direction = 0x17;
                TRACE( "     Bottom-Left    \r\n");
                break;
            }
            case 7 :
            {
            	direction = 0x18;
                TRACE( "         Left       \r\n");
                break;
            }
            case 8 :
            {
            	direction = 0x19;
                TRACE( "       Top-Left     \r\n");
                break;
            }
        }

        TRACE( "---------------------\r\n");

        positionOld = position;

        HAL_Delay(100);
    }
}

