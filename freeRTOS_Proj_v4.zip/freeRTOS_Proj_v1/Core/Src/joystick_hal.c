#include "joystick_hal.h"
#include "stm32L4xx.h"

extern I2C_HandleTypeDef hi2c1;

void hal_i2cMap(T_HAL_P i2cObj)
{
	return;
}

int hal_i2cStart(void)
{
	return 0;
}

int hal_i2cWrite(uint8_t slaveAddress, uint8_t *pBuf, uint16_t nBytes)
{
	HAL_I2C_Master_Transmit (&hi2c1, slaveAddress,(uint8_t *) pBuf, nBytes, 100);
	return 0;
}

int hal_i2cRead(uint8_t slaveAddress, uint8_t *pBuf, uint16_t nBytes)
{
	HAL_I2C_Master_Receive(&hi2c1, slaveAddress, (uint8_t *) pBuf, nBytes, 100);
	return 0;
}
