/*
 * Click_Joystick_STM.c
 *
 *  Created on: Jun 24, 2023
 *      Author: sss
 */

#include "Click_Joystick_types.h"
#include "Click_Joystick_config.h"
#include "trace.h"
#include "joystick_click.h"
#include "main.h"

uint8_t position;
uint8_t buttonState;
uint8_t positionOld = 1;
uint8_t buttonStateOld = 1;

void systemInit()
{
	/* Initialized interrupt, CS, reset pins as well as i2c module */
	HAL_GPIO_WritePin(GPIOB, RST_Pin, GPIO_PIN_SET);
}

void applicationInit()
{
//    joystick_i2cDriverInit( (T_JOYSTICK_P)&_MIKROBUS1_GPIO, (T_JOYSTICK_P)&_MIKROBUS1_I2C, _JOYSTICK_I2C_ADDRESS_0 );

    HAL_Delay(100);

    joystick_setDefaultConfiguration();

    TRACE( "---------------------");
    TRACE( "    Configuration    ");
    TRACE( "---------------------");
    TRACE( "    Joystick Click   ");
    TRACE( "---------------------");

    HAL_Delay(100);
}

void applicationTask()
{
    buttonState = joystick_pressButton();

    position = joystick_getPosition();

    HAL_Delay(10);

    if ( buttonState == 1 && buttonStateOld == 0 )
    {
        buttonStateOld = 1;

        TRACE("  Button is pressed ");
        TRACE( "---------------------");
    }

    if ( buttonState == 0 && buttonStateOld == 1 )
    {
        buttonStateOld = 0;
    }

    if ( positionOld != position )
    {
        switch ( position )
        {
            case 0 :
            {
                TRACE( "    Start position   ");
                break;
            }
            case 1 :
            {
                TRACE( "         Top        ");
                break;
            }
            case 2 :
            {
                TRACE( "      Top-Right     ");
                break;
            }
            case 3 :
            {
                TRACE( "        Right       ");
                break;
            }
            case 4 :
            {
                TRACE( "     Bottom-Right   ");
                break;
            }
            case 5 :
            {
                TRACE( "        Bottom      ");
                break;
            }
            case 6 :
            {
                TRACE( "     Bottom-Left    ");
                break;
            }
            case 7 :
            {
                TRACE( "         Left       ");
                break;
            }
            case 8 :
            {
                TRACE( "       Top-Left     ");
                break;
            }
        }

        TRACE( "---------------------");

        positionOld = position;

        HAL_Delay(100);
    }
}

