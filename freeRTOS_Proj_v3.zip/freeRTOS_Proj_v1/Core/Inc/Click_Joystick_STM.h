/*
 * Click_Joystick_STM.c
 *
 *  Created on: Jun 24, 2023
 *      Author: sss
 */

#ifndef INC_CLICK_JOYSTICK_STM_C_
#define INC_CLICK_JOYSTICK_STM_C_

void applicationTask();

#endif /* INC_CLICK_JOYSTICK_STM_C_ */
