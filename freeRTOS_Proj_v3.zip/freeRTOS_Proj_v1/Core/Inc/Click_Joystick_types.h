/*
 * Click_Joystick_types.h
 *
 *  Created on: Jun 24, 2023
 *      Author: sss
 */

#ifndef _JOYSTICK_T_
#define _JOYSTICK_T_

#include "stdint.h"

#ifndef _JOYSTICK_H_

#define T_JOYSTICK_P const uint8_t*

#endif
#endif
