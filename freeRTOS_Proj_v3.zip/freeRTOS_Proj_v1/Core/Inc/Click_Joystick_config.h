/*
 * Click_Joystick_config.h
 *
 *  Created on: Jun 24, 2023
 *      Author: sss
 */

#include "Click_Joystick_types.h"


const uint32_t _JOYSTICK_I2C_CFG[ 1 ] =
{
	100000
};
